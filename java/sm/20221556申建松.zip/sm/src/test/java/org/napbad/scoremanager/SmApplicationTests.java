package org.napbad.scoremanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
