rootProject.name = "scoremanager"
